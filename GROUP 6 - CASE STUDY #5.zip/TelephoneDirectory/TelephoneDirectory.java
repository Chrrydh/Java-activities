/**
 * CASE STUDY NUMBER 5
 * 
 * Telephone Directory – FILE HANDLING:
 * 
 * This file is created by the following authors:
 * - Bondoc, Shayne F.
 * - De Honor, Charry L.
 * - Rosales, Angel Abegail B.
 */

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.util.List;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class TelephoneDirectory extends JFrame {
    private JLabel label1, label2, label3, label4, label5, label6, recordLabel;
    private JTextField lNameField, fNameField, mNameField, addressField, numberField;
    private JButton addButton, deleteButton, updateButton;
    private JTable directoryTable;
    private DefaultTableModel tableModel;
    private TableRowSorter<DefaultTableModel> sorter;

    public TelephoneDirectory() {
        super("Telephone Directory");
        setSize(812, 755);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        Container content = getContentPane();
        content.setBackground(new Color(25, 20, 20)); 
        content.setLayout(null);

        // Add title label with border
        label1 = new JLabel("TELEPHONE DIRECTORY", SwingConstants.CENTER);
        label1.setBounds(100, 30, 600, 50);
        label1.setFont(new Font("Arial", Font.BOLD, 40));
        label1.setForeground(new Color(30, 215, 96)); 

        // Create a border for the label
        label1.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2)); 

        content.add(label1);


        // Add labels and text fields to get user input
        label2 = new JLabel("Last Name", SwingConstants.CENTER);
        label2.setBounds(60, 148, 200, 30);
        label2.setFont(new Font("Arial", Font.BOLD, 14));
        label2.setForeground(Color.WHITE);
        content.add(label2);

        lNameField = new JTextField();
        lNameField.setBounds(60, 117, 200, 30);
        content.add(lNameField);

        label3 = new JLabel("First Name", SwingConstants.CENTER);
        label3.setBounds(300, 148, 200, 30);
        label3.setFont(new Font("Arial", Font.BOLD, 14));
        label3.setForeground(Color.WHITE);
        content.add(label3);

        fNameField = new JTextField();
        fNameField.setBounds(300, 117, 200, 30);
        content.add(fNameField);

        label4 = new JLabel("Middle Name", SwingConstants.CENTER);
        label4.setBounds(534, 148, 200, 30);
        label4.setFont(new Font("Arial", Font.BOLD, 14));
        label4.setForeground(Color.WHITE);
        content.add(label4);

        mNameField = new JTextField();
        mNameField.setBounds(534, 117, 200, 30);
        content.add(mNameField);

        label5 = new JLabel("Address", SwingConstants.CENTER);
        label5.setBounds(100, 208, 600, 30);
        label5.setFont(new Font("Arial", Font.BOLD, 14));
        label5.setForeground(Color.WHITE);
        content.add(label5);

        addressField = new JTextField();
        addressField.setBounds(100, 179, 600, 30);
        content.add(addressField);

        label6 = new JLabel("Telephone Number", SwingConstants.CENTER);
        label6.setBounds(100, 267, 600, 30);
        label6.setFont(new Font("Arial", Font.BOLD, 14));
        label6.setForeground(Color.WHITE);
        content.add(label6);

        numberField = new JTextField();
        numberField.setBounds(100, 237, 600, 30);
        content.add(numberField);
        
        // Create add, delete, and update buttons
        addButton = new JButton("Insert");
        addButton.setBounds(50, 320, 200, 30);
        addButton.setActionCommand("Insert");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.setBackground(new Color(30, 215, 96));
        content.add(addButton);

        deleteButton = new JButton("Delete");
        deleteButton.setBounds(300, 320, 200, 30);
        deleteButton.setActionCommand("Delete");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteButton.setBackground(new Color(30, 215, 96));
        content.add(deleteButton);

        updateButton = new JButton("Update");
        updateButton.setBounds(550, 320, 200, 30);
        updateButton.setActionCommand("Update");
        updateButton.setFont(new Font("Arial", Font.BOLD, 14));
        updateButton.setBackground(new Color(30, 215, 96));
        content.add(updateButton);

        // Create table model and JTable
        tableModel = new DefaultTableModel();
        directoryTable = new JTable(tableModel);
        tableModel.addColumn("Name");
        tableModel.addColumn("Address");
        tableModel.addColumn("Telephone Number");

        // Create a TableRowSorter for the table model
        sorter = new TableRowSorter<>(tableModel);
        directoryTable.setRowSorter(sorter);
        directoryTable.setDefaultEditor(Object.class, null);
        sorter.setSortKeys(java.util.Arrays.asList(new RowSorter.SortKey(0, SortOrder.ASCENDING)));

        // Add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(directoryTable);
        scrollPane.setBounds(50, 370, 700, 305);
        content.add(scrollPane);

        // Set font and colors for the table
        directoryTable.setForeground(Color.WHITE);
        directoryTable.setBackground(Color.BLACK);
        //directoryTable.getTableHeader().setForeground(Color.WHITE);
        directoryTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        directoryTable.getTableHeader().setBackground(new Color(30, 215, 96));
        directoryTable.setGridColor(Color.white);

        // Create and set the ButtonHandler
        ButtonHandler buttonHandler = new ButtonHandler();
        addButton.addActionListener(buttonHandler);
        deleteButton.addActionListener(buttonHandler);
        updateButton.addActionListener(buttonHandler);
        
        // Add a mouse listener to the directoryTable to handle mouse clicks
        directoryTable.addMouseListener(new MouseAdapter() {
        	// Handle mouse click events
            public void mouseClicked(MouseEvent e) {
            	 // Get the index of the selected row
                int selectedRow = directoryTable.getSelectedRow();
                
                // Check if a row is selected
                if (selectedRow >= 0) {
                    int modelRow = directoryTable.convertRowIndexToModel(selectedRow);
                    // Split the full name into parts
                    String fullName = (String) tableModel.getValueAt(modelRow, 0);
                    String[] nameParts = fullName.split(" ");
                    // set all the textfields to the corresponding values in table
                    lNameField.setText(nameParts.length > 0 ? nameParts[0].replaceAll(",", "") : "");
                    fNameField.setText(nameParts.length > 1 ? nameParts[1] : "");
                    mNameField.setText(nameParts.length > 2 ? nameParts[2] : "");
                    addressField.setText((String) tableModel.getValueAt(modelRow, 1));
                    numberField.setText((String) tableModel.getValueAt(modelRow, 2));
                    
                }
            }
        });
        
        // If a user clicks the frame it will clear all textFields
        addMouseListener(new MouseAdapter() {
        	public void mouseClicked(MouseEvent e) {
           	 clearInputFields();
           }
        });
        
        // load the records to the table
        loadEntries();
        setResizable(false);
        setVisible(true);
    }
    
    // Handles actions for the Insert, Delete, and Update buttons
    private class ButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();

            if ("Insert".equals(command)) {
                addRecord();
            } else if ("Delete".equals(command)) {
                deleteRecord();
            } else if ("Update".equals(command)) {
                updateRecord();
            }
        }
    }
    // Method to add a record
    private void addRecord() {
        // Read input values
        String[] input = readInput();

        // Validate input
        if (input == null || input[0].isEmpty() || input[1].isEmpty() || input[2].isEmpty() || input[3].isEmpty() || input[4].isEmpty()) {
            JOptionPane.showMessageDialog(TelephoneDirectory.this, "Please fill in all required fields", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Combine last name, first name, and middle name 
        String name = input[0] + ", " + input[1] + " " + input[2];

        // Add the entry to the table model
        tableModel.addRow(new Object[]{name, input[3], input[4]});

        // Clear input fields
        clearInputFields();

        // Re-sort the table after adding a new entry
        sorter.sort();

        // Save updated data to file
        save();
    }

    // Method to delete a record
    private void deleteRecord() {
    	// store the selected row
        int selectedRow = directoryTable.getSelectedRow();
        if (selectedRow >= 0) {
            int modelRow = directoryTable.convertRowIndexToModel(selectedRow); // Convert view row index to model row index
            tableModel.removeRow(modelRow); // remove row from the table
            sorter.sort(); // Re-sort the table after deleting an entry
            save(); // Save updated data to file
        } else {
            JOptionPane.showMessageDialog(TelephoneDirectory.this, "Please select a row to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Method to update a record
    private void updateRecord() {
    	// store the selected row
        int selectedRow = directoryTable.getSelectedRow();
        if (selectedRow >= 0) {
            int modelRow = directoryTable.convertRowIndexToModel(selectedRow); // Convert view row index to model row index
            
            // Read input values
            String[] input = readInput();

            // Validate input
            if (input == null || input[0].isEmpty() || input[1].isEmpty() || input[2].isEmpty() || input[3].isEmpty() || input[4].isEmpty())  {
                JOptionPane.showMessageDialog(TelephoneDirectory.this, "Please fill in all required fields", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Combine first name, middle name, and last name into a single "Name" field with surname first
            String name = input[0] + ", " + input[1] + " " + input[2];
            
            // Update the selected row in the table model
            tableModel.setValueAt(name, modelRow, 0);
            tableModel.setValueAt(input[3], modelRow, 1);
            tableModel.setValueAt(input[4], modelRow, 2);

            // Clear input fields
            clearInputFields();

            // Re-sort the table after updating the entry
            sorter.sort();

            // Save updated data to file
            save();
        } else {
        	 JOptionPane.showMessageDialog(TelephoneDirectory.this, "Please select a row to update", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Read user input from the textfield
    private String[] readInput() {
        String lastName = lNameField.getText().trim();
        String firstName = fNameField.getText().trim();
        String middleName = mNameField.getText().trim();
        String address = addressField.getText().trim();
        String telephone = numberField.getText().trim();
        
        // return a String array
        return new String[]{lastName, firstName, middleName, address, telephone};
    }
    
    // Saves the current table data to "TelephoneDirectory.txt"
    private void save() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("TelephoneDirectory.txt"))) {
            // Retrieve all rows from the table
            List<String[]> rows = new ArrayList<>();
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                String name = (String) tableModel.getValueAt(i, 0);
                String address = (String) tableModel.getValueAt(i, 1);
                String telephone = (String) tableModel.getValueAt(i, 2);
                rows.add(new String[]{name, address, telephone});
            }

            // Sort the rows by the Name column (surname first)
            rows.sort(Comparator.comparing(o -> o[0]));

            // Write sorted rows to the file
            for (String[] row : rows) {
                bw.write(String.join(";", row));
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to clear input fields
    private void clearInputFields() {
        lNameField.setText("");
        fNameField.setText("");
        mNameField.setText("");
        addressField.setText("");
        numberField.setText("");
    }

    // Method to load existing entries from a file
    private void loadEntries() {
        try (BufferedReader br = new BufferedReader(new FileReader("TelephoneDirectory.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 3) {
                    tableModel.addRow(parts); // adds the record to the table model
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    // Main method
    public static void main(String[] args) {
        new TelephoneDirectory();
    }
}
