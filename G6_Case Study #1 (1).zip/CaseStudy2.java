/**
 * CASE STUDY NUMBER 2
 * 
 * Non-vertical Straight Lines:
 * 
 * This file is created by the following authors:
 * - Bondoc, Shayne F.
 * - De Honor, Charry L.
 * - Rosales, Angel Abegail B.
 */

import java.util.Scanner;

public class CaseStudy2 {
    static Scanner scanner = new Scanner(System.in);
    
    // Main method regulating the execution of the program.
    public static void main(String[] args) {
        boolean continueProg = true;
        
        // Loop to continuously request feedback from the user.
        while (continueProg) {
            int problem = getProblem(); // Ask the user to select the type of conversion.
            
            // Use a switch statement to manage different conversion scenarios.
            switch(problem) {
                case 1:
                    getTwoPointForm(); // Convert to two-point form.
                    break;
                case 2:
                    getPointSlopeForm(); // Convert to point-slope form.
                    break;
                default:
                    System.out.println("Invalid input, try again.");
                    continue;
            }
            
            // Loop to determine if the user wants to proceed.
            do {
                System.out.print("\nDo another conversion? (Y or N): ");
                char answer = Character.toLowerCase(scanner.next().charAt(0));

                if (answer == 'n') {
                    continueProg = false; // End program if user enters 'N'.
                    break;
                } else if (answer == 'y') {
                    break; // Continue with another conversion if user enters 'Y'.
                } else {
                    System.out.println("Invalid input.");
                }
            } while (true);
        }
    }
    
    // Function to prompt the user to select the type of conversion.
    public static int getProblem() {
        System.out.println("\nSelect the form that you would like to convert to slope-intercept form:");
        System.out.println("1) Two-point form (you know the points on the line)");
        System.out.println("2) Point-slope form (you know the line's slope and one point");
        
        System.out.print("=> ");
        int problem = scanner.nextInt(); // Read user input
        
        return problem;
    }
    
    // Create a function that manages the conversion of equations from the two-point form.
    public static void getTwoPointForm() {
        // Requesting two points' coordinates.
        System.out.println("\nEnter the x-y coordinates of the first point separated by a space=> ");
        double x1 = scanner.nextDouble();
        double y1 = scanner.nextDouble();
        
        System.out.println("Enter the x-y coordinates of the second point separated by a space=> ");
        double x2 = scanner.nextDouble();
        double y2 = scanner.nextDouble();
        
        // Displaying two-point form equation and slope-intercept form.
        displayTwoPointForm(x1, x2, y1, y2);
        double [] result = slopeInterceptFromTwoPoint(x1, x2, y1, y2);
        displaySlopeIntercept(result[1], result[0]);
    }
    
    // Approach for converting equations from point-slope form.
    public static void getPointSlopeForm() {
        // Prompting for slope and a point.
        System.out.print("\nEnter the slope=> ");
        double m = scanner.nextDouble();
        
        System.out.print("Enter the x-y coordinates of the point separated by a space=> ");
        double x = scanner.nextDouble();
        double y = scanner.nextDouble();        
        
        // Displaying point-slope form equation and slope-intercept form.
        displayPointSlope(x, y, m);
        System.out.println();
        
        double yIntercept = interceptFromPointSlope(x, y, m);
        displaySlopeIntercept(yIntercept, m);    
    }
    
    // Procedure to determine the slope and y-intercept using two specified points.
    public static double[] slopeInterceptFromTwoPoint(double x1, double x2, double y1, double y2) {
        // Calculate the slope (m) using the formula: (y2 - y1) / (x2 - x1).
        double m = (y2 - y1) / (x2 - x1);
        // Calculate the y-intercept (b) using the formula: y1 - (m * x1).
        double yIntercept = y1 - (m * x1);
        
        // Store the slope and y-intercept in an array.
        double[] result = {m, yIntercept};
        return result;
    }

    // Function to calculate the y-intercept from the point-slope form.
    public static double interceptFromPointSlope(double x, double y, double m) {
        // Calculate the y-intercept using the formula: y - m * x
        return y - m * x;
    }

    // Technique for displaying the equation in two-point form.
    public static void displayTwoPointForm(double x1, double x2, double y1, double y2) {
        System.out.println("\nTwo-point form");
        // Print the equation in the format: (y2 - y1) / (x2 - x1)
        System.out.printf("     (%.2f) - (%.2f)\n", y2, y1);
        System.out.println("m = ----------------");
        System.out.printf("     (%.2f) - (%.2f)\n", x2, x1);
    }

    // Technique for displaying the equation in point-slope form.
    public static void displayPointSlope(double x, double y, double m) {
        System.out.println("\nPoint-slope form");
        // Print the equation in the format: y ± m(x ± x1).
        System.out.printf("\ty %s %.2f = %.2f (x %s %.2f)", y < 0 ? "+" : "-", Math.abs(y), m, x < 0 ? "+" : "-", Math.abs(x));
    }

    // Method to display the equation in slope-intercept form.
    public static void displaySlopeIntercept(double yIntercept, double m) {
        System.out.println("\nSlope-intercept form");
        // Print the equation in the format: y = mx ± b.
        System.out.printf("\ty = %.2fx %s %.2f\n", m, yIntercept < 0 ? "-" : "+", Math.abs(yIntercept));
    }
}
