/**
 * CASE STUDY NUMBER 1
 * 
 * Intravenous Rate Assistant:
 * 
 * This file is created by the following authors:
 * - Bondoc, Shayne F.
 * - De Honor, Charry L.
 * - Rosales, Angel Abegail B.
 */

import java.util.Scanner;

public class CaseStudy1 {
	static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {

		System.out.println("INTRAVENOUS RATE ASSISTANT\n");

		// Loop to keep the program running until the user decides to quit.
		while(true) {
			int problem = get_problem();
			
			// Check if user wants to quit.
			if(problem == 5) {
				break; // Exit loop and program.
			}
			

			// Using a switch statement to execute the user's choice.
			switch(problem) {

				// Calculate drops per minute.
				case 1:
					get_rate_drop_factor();
					break;


				// Calculate ml per hour for a volume over time.
				case 2:
					System.out.print("Enter number of hours=> ");
					int numberOfHours = scanner.nextInt();
					int rMph = fig_ml_hr(numberOfHours);
					System.out.println("The rate in milliliters per hours is " + rMph + ".");
					break;


				// Calculate ml per hour based on weight and concentration.
				case 3:
					System.out.println("The rate in milliliters per hour is " + get_kg_rate_conc() + ".");
					break;


				// Calculate ml per hour based on unit concentration.
				case 4:
					System.out.println("The rate in milliliters per hour is " + get_units_conc() + ".");
					break;


				// Prints invalid input.
				default:
					System.out.println("Invalid input, input should be from 1-5");
			}
			System.out.println(); // Add space for readability.
		}
	}
	
	// Display options and get user input.
	public static int get_problem() {
		System.out.println("Enter the number of the problem you wish to solve.");
		System.out.println("\tGIVEN A MEDICAL ORDER IN\t\tCALCULATE RATE IN");
		
		System.out.println("(1)\tml/hr & tubig drop factor\t\t     drops / min");
		System.out.println("(2)\t1L for n hr\t\t\t\t     ml / hr");
		System.out.println("(3)\tmg/kg/hr & concentration in mg/ml\t     ml / hr");
		System.out.println("(4)\tunits/hr & concentration in units/ml\t     ml / hr");
		System.out.println("(5)\tQUIT");
		
		System.out.print("Problem => ");
		int problem = scanner.nextInt();
		
		return problem;
	}
	
	// Get user input and calculate drops per minute.
	public static void get_rate_drop_factor() {
		System.out.print("Enter rate in ml/hr=> ");
		double rate = scanner.nextDouble();
		System.out.print("Enter tubing's drop factor (drops/ml)=> ");
		double dropFactor = scanner.nextDouble();
		System.out.println("The drop rate per minute is " + fig_drops_min(rate, dropFactor) + ".");
	}
	
	// Get user input and calculate ml per hour based on weight and concentration.
	public static int get_kg_rate_conc() {
		System.out.print("Enter rate in mg/kg/hr=> ");
		double rate = scanner.nextDouble();
		System.out.print("Enter patient weight in kg=> ");
		double weight = scanner.nextDouble();
		System.out.print("Enter concentration in mg/ml=> ");
		double conc = scanner.nextInt();
		
		return by_weight(rate, weight, conc);
	
	}

	// Get user input and calculate ml per hour based on units and concentration.
	public static int get_units_conc() {
		System.out.print("Enter rate in units/hr=> ");
		double rate = scanner.nextDouble();
		System.out.print("Enter concentration in units/ml=> ");
		double conc = scanner.nextDouble();
		
		return by_units(rate, conc);
	}
	
	// Calculates drops per minute.
	public static int fig_drops_min(double rate, double dropFactor) {
		return (int) Math.round(rate * dropFactor / 60.0);
	}
	
	// Calculates ml per hour for given volume over time.
	public static int fig_ml_hr(double numHours) {
		return (int) Math.round(1000.0 / numHours);
	}
	
	// Calculates ml per hour based on weight and drug concentration.
	public static int by_weight(double rate, double weight, double conc) {
		return (int) Math.round(rate * weight / conc);
	}
	
	// Calculates ml per hour based on units and concentration.
	public static int by_units(double rate, double conc) {
		return (int) Math.round(rate / conc);
	}

}
