/**
 * CASE STUDY NUMBER 3
 * 
 * ΩMG:
 * 
 * This file is created by the following authors:
 * - Bondoc, Shayne F.
 * - De Honor, Charry L.
 * - Rosales, Angel Abegail B.
 */


import java.util.Scanner;

public class CaseStudy3 {
	public static void main(String[] args) {
		// Array of color codes according to the resistor color code.
		final String[] COLOR_CODES = {"black", "brown", "red", "orange", "yellow", "green", "blue", "violet", "gray", "white"};
		Scanner scanner = new Scanner(System.in);
		boolean continueProg = true; // For controlling the program loop.
		int resistanceValue = 0, size = COLOR_CODES.length; // Holds the calculated resistance value and length of the COLOR_CODES array.
		
		// Main loop for processing user input and calculating resistance.
		while(continueProg) {
			// Instructions for user input.
			System.out.println("Enter the colors of the resistor’s three bands, beginning with the");
			System.out.println("band nearest the end. Type the colors in lowercase letters only,");
			System.out.println("NO CAPS.");

			// Asks for the first color band.
			System.out.print("Band 1 => ");
			String band1 = scanner.nextLine().toLowerCase();

			// Asks for the second color band.
			System.out.print("Band 2 => ");
			String band2 = scanner.nextLine().toLowerCase();

			// Asks for the third color band.
			System.out.print("Band 3 => ");
			String band3 = scanner.nextLine().toLowerCase();
			
			// Find indexes of each inputted colors in the array.
			int band1Index = search(COLOR_CODES, size, band1);
			int band2Index = search(COLOR_CODES, size, band2);
			int band3Index = search(COLOR_CODES, size, band3);


			// Validate color codes
			if(!(band1Index == -1 || band2Index == -1 || band3Index == -1)) {
				// Calculate resistance
				resistanceValue = (band1Index * 10 + band2Index) * (int) Math.pow(10, band3Index);
				
				// Converts resistance value to kilo-ohms.
				resistanceValue /= 1000;
				
				// Displays the result.
				System.out.println("Resistance value: " + resistanceValue + " kilo-ohms");

			} else {
				
				// Prints invalid input.
				System.out.print("Invalid color: ");

				// Prints the invalid color entered by the user.
				if (band1Index == -1) {
					System.out.println(band1);
				} else if (band2Index == -1) {
					System.out.println(band2);
				} else if (band3Index == -1){
					System.out.println(band3);	
				}
			}

			// Asks the user if they want to decode another resistor.
            do {
                System.out.println("Do you want to decode another resistor? (Y/N)");
                System.out.print("=> ");
                char ans = scanner.nextLine().charAt(0);

                if (Character.toLowerCase(ans) == 'n') {
                	continueProg = false;
                    break;
                } else if (Character.toLowerCase(ans) == 'y') {
                    break;
                } else {
                	System.out.println("Invalid input.");
                }
            } while(true);
		}
	}
	

	// Method to search for a string in the COLOR_CODES array and return its index if found and -1 if not.
	public static int search(String[] COLOR_CODES, int size, String targetStr) {
		
		for(int i = 0; i < COLOR_CODES.length; i++) {
			if(targetStr.equals(COLOR_CODES[i])) {
				return i;
			}
		}	
		return -1;
	}

}
