/**
 * CASE STUDY NUMBER 3
 * 
 * Billing Software:
 * 
 * This file is created by the following authors:
 * - Bondoc, Shayne F.
 * - De Honor, Charry L.
 * - Rosales, Angel Abegail B.
 */


// Class called Fruit
class Fruit {
    // To store the code and name of the fruit
    private int code;
    private String name;

    // Static variable to keep track of the number of fruits created
    static int counter = 1000;

    // Takes the name of the fruit as a parameter
    Fruit(String name) {

        this.name = name;
    }
}


// Class called Fruitingms
class Fruitingms extends Fruit {
    private double available_kgs;
    private double price_per_kg; 

    Fruitingms(String name, double available_kgs, double price_per_kg) {
        super(name); // call the constructor of the superclass
        this.available_kgs = available_kgs; // set the available kilograms of the fruit
        this.price_per_kg = price_per_kg; // set the price per kilogram of the fruit
    }

    public double getprice() {
        return price_per_kg; // return the price per kilogram of the fruit
    }

    public boolean checkavailability(double need) {
        if (available_kgs < need) {
            return false; // return false if the available kilograms are less than the needed amount
        }
        return true; 
    }

    public void updateavailability(double need) {
        available_kgs = available_kgs - need; // update the available kilograms of the fruit
    }
}



// Class called Fruitinpcs
class Fruitinpcs extends Fruit {
    private double available_pcs;
    private double price_per_piece;

    Fruitinpcs(String name, double available_pcs, double price_per_piece) {
        super(name); // call the constructor of the superclass
        this.available_pcs = available_pcs; // set the available pieces of the fruit
        this.price_per_piece = price_per_piece; // set the price per piece of the fruit
    }

    public double getprice() {
        return price_per_piece; // return the price per piece of the fruit
    }

    public boolean checkavailability(double need) {
        if (available_pcs < need) {
            return false; // return false if the available pieces are less than the needed amount
        }
        return true; // return true otherwise
    }

    public void updateavailability(double need) {
        available_pcs = available_pcs - need; // update the available pieces of the fruit
    }
}



// Class called Sale
class Sale {
    private int code; 
    private Fruit fobj; // private variable to store the fruit object
    private double unit; 
    private double amount;
    static int counter = 2000; // static variable to keep track of the number of sales

    Sale(Fruit fobj, double unit) {
        this.fobj = fobj; // set the fruit object
        this.unit = unit; // set the number of units sold
    }

    public double Bill() {
        if (fobj instanceof Fruitingms) {
            Fruitingms fruit = (Fruitingms) fobj; // cast the fruit object to Fruitingms

            if (!fruit.checkavailability(unit)) {
                System.out.println("Item not available");
                return -1; // return -1 indicating an error
            }
            amount = fruit.getprice() * unit; // calculate the total amount
            if (amount > 1500) {
                amount = discount(); // apply discount if the total amount is greater than 1500
            }
            fruit.updateavailability(unit); // update the available kilograms of the fruit
            return amount;

        } else if (fobj instanceof Fruitinpcs) {
            Fruitinpcs fruit = (Fruitinpcs) fobj;

            // checks fruit availability
            if (!fruit.checkavailability(unit)) {
                System.out.println("Item not available");
                return -1; //
            }

            amount = fruit.getprice() * unit; // calculate the total amount
            if (amount > 1500) {
                amount = discount(); // apply discount if the total amount is greater than 1500
            }

            fruit.updateavailability(unit); // update the available pieces of the fruit
            return amount; // return the total amount

        } else {
            System.out.println("Invalid fruit type");
            return -1;
        }
    }

    private double discount() {
        double disc = amount * 0.05; // calculate the discount
        amount = amount - disc; // apply the discount
        return amount; // return the discounted amount
    }
}



// Main class
class Demo {
    public static void main(String[] args) {
        Fruit fobj = new Fruitingms("apple", 50.6, 80.0);
        
        // prints the output
        Sale s = new Sale(fobj, 2.0); 
        System.out.println(s.Bill());
        Fruit fobj1 = new Fruitinpcs("banana", 200, 3.0); 
        Sale s1 = new Sale(fobj1, 10);
        System.out.println(s1.Bill());

    }

}
