/**
 * CASE STUDY NUMBER 2
 * 
 * MyDate Class:
 * 
 * This file is created by the following authors:
 * - Bondoc, Shayne F.
 * - De Honor, Charry L.
 * - Rosales, Angel Abegail B.
 */

public class MyDate {
    // Using instance variables efficiently stores essential information such as year, month, and day. 
    private int year;
    private int month;
    private int day;
    
    // Static final variables representing months, days, and days in months
    public static final String[] MONTHS = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"
            ,"Oct", "Nov", "Dec"};
    public static final String[] DAYS = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    public static final int[] DAY_IN_MONTHS = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    //  Constructor to initialize a MyDate object with the provided year, month, and day.
    public MyDate(int year, int month, int day) {
        setDate(year, month, day);
    }

    // Method to determine whether a given year is a leap year or not.
    public boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

    // A way to determine if the given date is valid.
    public boolean isValidDate(int year, int month, int day) {
        if (year < 1 || year > 9999 || month < 1 || month > 12) {
            return false;
        }

        // Determine the maximum number of days in the current month.
        int dayMax = DAY_IN_MONTHS[month - 1];
        
        // Adjust dayMax for February in leap years.
        if(month == 2 && isLeapYear(year)) {
            dayMax = 29;
        }

        // return true if within a valid range for the month
        return day > 0 && day <= dayMax;
    }

    // Method to calculate the day of the week for a specific date.
    public static int getDayOfWeek(int year, int month, int day) {
        if (month < 3) {
            month += 12;
            year--;
        }
        int century = year / 100;
        year %= 100;
        // Apply Zeller's Congruence formula to calculate the day of the week
        int dayOfWeek = (day + ((13 * (month + 1)) / 5) + year + (year / 4) + (century / 4) + (5 * century)) % 7;
        return (dayOfWeek + 6) % 7; // Adjust so that 0 is for Sunday
    }

    // Setter method to set the date after validation
    public void setDate(int year, int month, int day) {
        if(!isValidDate(year, month, day)) {
            throw new IllegalArgumentException("Invalid year, month, or day!");
        }
        this.year = year;
        this.month = month;
        this.day = day;
    }

    // Setter method to set the year after validation
    public void setYear(int year) {
        if(year < 1 || year > 9999) {
            throw new IllegalArgumentException("Invalid year!");
        }
        this.year = year;
    }

    // Setter method to set the month after validation
    public void setMonth(int month) {
        if(month < 1 || month > 12) {
            throw new IllegalArgumentException("Invalid year!");
        }
        this.month = month;
    }

    // Setter method to set the day after validation
    public void setDay(int day) {
        // Determine the max number of days in the current month
        int dayMax = DAY_IN_MONTHS[month - 1];
        
        // Adjust dayMax for Feb if the current year is a leap year
        if(month == 2 && isLeapYear(year)) {
            dayMax = 29;
        }

        // Check if the day is within the range of valid days for the current month
        if(day < 1 || day > dayMax) {
            throw new IllegalArgumentException("Invalid year!");
        }
        this.day = day;
    }

    // Getter method used to retrieve the year
    public int getYear() {
        return this.year;
    }
    // Getter method used to retrieve the month
    public int getMonth() {
        return this.month;
    }
    // Getter method used to retrieve the day
    public int getDay() {
        return this.day;
    }

    // Override the toString method to return a String representatio of the date
    @Override
    public String toString() {
        // Call the method getDayOfWeek to calculate the day of the week of the current day
        int dayOfWeek = getDayOfWeek(this.year, this.month, this.day);
        
        // Get the name of the day and month
        String day = DAYS[dayOfWeek];
        String month = MONTHS[this.month - 1];

        // return the formatted string representation of the date
        return day + " " + this.day + " " + month + " " + year;
    }

    // Method for moving to the next day and returning the updated instance.
    public MyDate nextDay() {
        // Determine the maximum number of days in the current month.
        int dayMax = DAY_IN_MONTHS[month - 1];

        // Adjust dayMax for February in leap years.
        if(this.month == 2 && isLeapYear(this.year)) {
            dayMax = 29;
        }
        // Check if incrementing the day exceeds the maximum days in the month.
        if((this.day + 1) > dayMax) {
            // If so, move to the next month.
            nextMonth();
            // Reset the day to the first day of the next month.
            this.day = 1;
        } else {
            // Increment the day by one.
            this.day++;
        }
        return this; // Return the updated instance.
    }

    // Method to move to the next month and return the updated instance.
    public MyDate nextMonth() {
        // Check if the current month is December.
        if(this.month == 12) {
            // If so, set the month to January and increment the year.
            this.month = 1;
            this.year++;
        } else {
            // Otherwise, increment the month.
            this.month++;
        }
        // Determine the maximum number of days in the new month.
        int dayMax = DAY_IN_MONTHS[month];

        // Adjust dayMax for February in leap years.
        if(month == 2 && isLeapYear(year)) {
            dayMax++;
        }
        // If the current day exceeds the maximum days in the new month, adjust it.
        if(this.day > dayMax) {
            this.day = dayMax;
        }
        return this;// Return the updated instance.
    }

    // Method for moving to the next year and returning an updated instance.
    public MyDate nextYear() {
        // Check if the year is within the valid range.
        if(year > 9999) {
            throw new IllegalArgumentException("Year out of range!");
        }
        // Increment the year.
        this.year++;

        // Determine the maximum number of days in the current month.
        int dayMax = DAY_IN_MONTHS[this.month - 1];

        // If it's February 29th and the next year is not a leap year, adjust the day to 28.
        if (this.month == 2 && this.day == 29 && !isLeapYear(this.year)) {
            this.day = 28;
        }
        // If the current day exceeds the maximum days, adjust it.
        else if (this.day > dayMax) {
            this.day = dayMax;
        }

        return this; // Return the updated instance
    }

    // Method to move to the previous day and return the updated instance.
    public MyDate previousDay() {
        // Check if the current day is the first day of the month.
        if(this.day == 1) {
             // If so, move to the previous month.
            this.previousMonth();
             // Determine the maximum number of days in the new month.
            int dayMax = DAY_IN_MONTHS[this.month - 1];

            // Adjust dayMax for February in leap years.
            if(this.month == 2 && isLeapYear(this.year)) {
                dayMax = 29;
            }
            // Set the day to the last day of the previous month.
            this.day = dayMax;
        } else {
            // Otherwise, decrement the day by one.
            this.day--;
        }

        return this;  // Return the updated instance.
    }

    // Method to move to the previous month and return the updated instance.
    public MyDate previousMonth() {
         // Check if the current month is January.
        if(this.month == 1) {
            // If so, set the month to December and decrement the year.
            this.month = 12;
            this.year--;
        } else {
            // Otherwise, decrement the month.
            this.month--;
        }

        // Determine the maximum number of days in the new month.
        int dayMax = DAY_IN_MONTHS[month - 1];

        // Adjust dayMax for February in leap years.
        if(month == 2 && isLeapYear(year)) {
            dayMax++;
        }

        // If the current day exceeds the maximum days in the new month, adjust it.
        if(this.day > dayMax) {
            this.day = dayMax;
        }
        return this; // Return the updated instance.
    }

    // Method to move to the previous year and return the updated instance.
    public MyDate previousYear() {
        // Decrement the year.
        this.year--;
        // Determine the maximum number of days in the current month.
        int dayMax = DAY_IN_MONTHS[month - 1];


        // Adjust dayMax for February in leap years.
        if(month == 2 && isLeapYear(year)) {
            dayMax++;
        }
        // If the current day exceeds the maximum days in the current month, adjust it.
        if (day > dayMax) {
            this.day = dayMax;
        }
        return this;// Return the updated instance.
    }

}


