/**
 * CASE STUDY NUMBER 2
 * 
 * MyDateDemo Class:
 * 
 * This file is created by the following authors:
 * - Bondoc, Shayne F.
 * - De Honor, Charry L.
 * - Rosales, Angel Abegail B.
 */

public class MyDateDemo2 {
    public static void main(String[] args) {
        // Write a test program that tests the nextDay() in a loop, by printing the dates from 28 Dec 2011 to 2 Mar 2012.

		MyDate date = new MyDate(2011, 12, 28);
		// Loop until the date reaches 2 Mar 2012.
		while(!(date.getYear() == 2012 && date.getMonth() == 3 && date.getDay() == 2)) {
			
			// Print the current date.
			System.out.println(date);

			// Move to the next day.
            date.nextDay();
		}

        // Print the final date.
        System.out.println(date);
    }
}
