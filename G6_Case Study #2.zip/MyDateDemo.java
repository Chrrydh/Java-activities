/**
 * CASE STUDY NUMBER 2
 * 
 * MyDateDemo Class:
 * 
 * This file is created by the following authors:
 * - Bondoc, Shayne F.
 * - De Honor, Charry L.
 * - Rosales, Angel Abegail B.
 */

public class MyDateDemo {

	public static void main(String[] args) {
		// Test cases for MyDate class
		MyDate d1 = new MyDate(2012, 2, 28); // Creating a new MyDate instance for February 28, 2012
		System.out.println(d1); // Printing the current date: Tuesday 28 Feb 2012
		System.out.println(d1.nextDay()); // Printing the next day: Wednesday 29 Feb 2012
		System.out.println(d1.nextDay()); // Printing the next day after the previous call: Thursday 1 Mar 2012

		System.out.println(d1.nextMonth()); // Printing the next month: Sunday 1 Apr 2012
		System.out.println(d1.nextYear()); // Printing the next year: Monday 1 Apr 2013
		System.out.println("");
		MyDate d2 = new MyDate(2012, 1, 2); // Creating a new MyDate instance for January 2, 2012
		System.out.println(d2); // Printing the current date: Monday 2 Jan 2012
		System.out.println(d2.previousDay()); // Printing the previous day: Sunday 1 Jan 2012
		System.out.println(d2.previousDay()); // Printing the previous day after the previous call: Saturday 31 Dec 2011
		System.out.println(d2.previousMonth()); // Printing the previous month: Wednesday 30 Nov 2011
		System.out.println(d2.previousYear()); // Printing the previous year: Tuesday 30 Nov 2010
		MyDate d3 = new MyDate(2012, 2, 29); // Creating a new MyDate instance for February 29, 2012 (leap year)
		System.out.println(d3.previousYear()); // Printing the previous year: Monday 28 Feb 2011
		MyDate d4 = new MyDate(2099, 11, 31); // Attempt to create an invalid date, throws exception
		MyDate d5 = new MyDate(2011, 2, 29); // Attempt to create an invalid date, throws exception
	}

}

