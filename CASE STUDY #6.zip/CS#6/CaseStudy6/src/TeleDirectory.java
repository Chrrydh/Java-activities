/**
 * CASE STUDY NUMBER 6
 * 
 * Telephone Directory – DATABASE
 * 
 * This file is created by the following authors:
 * - Bondoc, Shayne F.
 * - De Honor, Charry L.
 * - Rosales, Angel Abegail B.
 */

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

/**
 * A simple telephone directory application using Java Swing and MySQL database.
 * Allows users to insert, update, and delete entries, and displays them in a table.
 */

public class TeleDirectory extends JFrame {
    private JLabel label1, label2, label3, label4, label5, label6;
    private JTextField lNameField, fNameField, mNameField, addressField, numberField;
    private JButton addButton, deleteButton, updateButton, clearButton;
    private JTable directoryTable;
    private DefaultTableModel tableModel;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3307/telephonedirectory";
    private static final String USER = "root";
    private static final String PASS = "";

    /**
     * Constructs the TeleDirectory application window.
     */

    public TeleDirectory() {
        super("Telephone Directory");
        setSize(812, 755);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        Container content = getContentPane();
        content.setBackground(new Color(25, 20, 20));
        content.setLayout(null);

        // Setting up UI components
        // Labels and text fields setup
        label1 = new JLabel("TELEPHONE DIRECTORY", SwingConstants.CENTER);
        label1.setBounds(100, 30, 600, 50);
        label1.setFont(new Font("Arial", Font.BOLD, 40));
        label1.setForeground(new Color(30, 215, 96));
        label1.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        content.add(label1);

        label2 = new JLabel("Last Name", SwingConstants.CENTER);
        label2.setBounds(60, 148, 200, 30);
        label2.setFont(new Font("Arial", Font.BOLD, 14));
        label2.setForeground(Color.WHITE);
        content.add(label2);

        lNameField = new JTextField();
        lNameField.setBounds(60, 117, 200, 30);
        content.add(lNameField);

        label3 = new JLabel("First Name", SwingConstants.CENTER);
        label3.setBounds(300, 148, 200, 30);
        label3.setFont(new Font("Arial", Font.BOLD, 14));
        label3.setForeground(Color.WHITE);
        content.add(label3);

        fNameField = new JTextField();
        fNameField.setBounds(300, 117, 200, 30);
        content.add(fNameField);

        label4 = new JLabel("Middle Name", SwingConstants.CENTER);
        label4.setBounds(534, 148, 200, 30);
        label4.setFont(new Font("Arial", Font.BOLD, 14));
        label4.setForeground(Color.WHITE);
        content.add(label4);

        mNameField = new JTextField();
        mNameField.setBounds(534, 117, 200, 30);
        content.add(mNameField);

        label5 = new JLabel("Address", SwingConstants.CENTER);
        label5.setBounds(100, 208, 600, 30);
        label5.setFont(new Font("Arial", Font.BOLD, 14));
        label5.setForeground(Color.WHITE);
        content.add(label5);

        addressField = new JTextField();
        addressField.setBounds(100, 179, 600, 30);
        content.add(addressField);

        label6 = new JLabel("Telephone Number", SwingConstants.CENTER);
        label6.setBounds(100, 267, 600, 30);
        label6.setFont(new Font("Arial", Font.BOLD, 14));
        label6.setForeground(Color.WHITE);
        content.add(label6);

        numberField = new JTextField();
        numberField.setBounds(100, 237, 600, 30);
        content.add(numberField);

        // Buttons setup
        addButton = new JButton("Insert");
        addButton.setBounds(50, 320, 200, 30);
        addButton.setActionCommand("Insert");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.setBackground(new Color(30, 215, 96));
        content.add(addButton);

        deleteButton = new JButton("Delete");
        deleteButton.setBounds(300, 320, 200, 30);
        deleteButton.setActionCommand("Delete");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteButton.setBackground(new Color(30, 215, 96));
        content.add(deleteButton);

        updateButton = new JButton("Update");
        updateButton.setBounds(550, 320, 200, 30);
        updateButton.setActionCommand("Update");
        updateButton.setFont(new Font("Arial", Font.BOLD, 14));
        updateButton.setBackground(new Color(30, 215, 96));
        content.add(updateButton);

        clearButton = new JButton("Clear");
        clearButton.setBounds(644, 83, 89, 23);
        clearButton.setBackground(new Color(30, 215, 96));
        clearButton.setActionCommand("Clear");
        clearButton.setFont(new Font("Arial", Font.BOLD, 14));
        getContentPane().add(clearButton);

        // Table setup
        tableModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Prevent cells from being editable
            }
        };

        directoryTable = new JTable(tableModel);
        tableModel.addColumn("Name");
        tableModel.addColumn("Address");
        tableModel.addColumn("Telephone Number");
        
        // Allows the directoryTable to be scrollable
        JScrollPane scrollPane = new JScrollPane(directoryTable);
        scrollPane.setBounds(50, 370, 700, 305);
        content.add(scrollPane);

        directoryTable.setForeground(Color.WHITE);
        directoryTable.setBackground(Color.BLACK);
        directoryTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        directoryTable.getTableHeader().setBackground(new Color(30, 215, 96));
        directoryTable.setGridColor(Color.white);

        // Button handlers and mouse listener setup
        ButtonHandler buttonHandler = new ButtonHandler();
        addButton.addActionListener(buttonHandler);
        deleteButton.addActionListener(buttonHandler);
        updateButton.addActionListener(buttonHandler);
        clearButton.addActionListener(buttonHandler);

        directoryTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = directoryTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int modelRow = directoryTable.convertRowIndexToModel(selectedRow);
                    String fullName = (String) tableModel.getValueAt(modelRow, 0);
                    String[] nameParts = fullName.split(" ");
                    lNameField.setText(nameParts.length > 0 ? nameParts[0].replaceAll(",", "") : "");
                    fNameField.setText(nameParts.length > 1 ? nameParts[1] : "");
                    mNameField.setText(nameParts.length > 2 ? nameParts[2] : "");
                    addressField.setText((String) tableModel.getValueAt(modelRow, 1));
                    numberField.setText((String) tableModel.getValueAt(modelRow, 2));
                }
            }
        });

        // Load records from the database
        loadEntries();
        setResizable(false);
        setVisible(true);
    }

    /**
     * ActionListener implementation to handle button clicks.
     */

    private class ButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            // Switch case to handle buttons actions when specific button is clicked
            switch (command) {
                case "Insert":
                    addRecord();
                    break;
                case "Delete":
                    deleteRecord();
                    break;
                case "Update":
                    updateRecord();
                    break;
                case "Clear":
                    clearInputFields();
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * Adds a record to the database based on user input.
     */

    private void addRecord() {
        // Reads the input from the gui and stores it in an array
        String[] input = readInput();
        
        // To validate if the user filled in all required fields, middle initial is not required
        if (input == null || input[0].isEmpty() || input[1].isEmpty() || input[3].isEmpty() || input[4].isEmpty()) {
            JOptionPane.showMessageDialog(TeleDirectory.this, "Please fill in all required fields", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String middleName = input[2].isEmpty() ? "" : " " + input[2];
        
        // Construct the full name in the format: "Last Name, First Name Middle Initial".
        String name = input[0] + ", " + input[1] + middleName;
        
        // Try-with-resources to ensure the database connection and statement are closed automatically
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO contacts (lname, fname, mInitial, address, telephone) VALUES (?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
            
            // Set the parameters for the PreparedStatement using the user input.
            pstmt.setString(1, input[0]); // Set last name
            pstmt.setString(2, input[1]); // Set first name
            pstmt.setString(3, input[2]); // Set middle initial (can be empty)
            pstmt.setString(4, input[3]); // Set address
            pstmt.setString(5, input[4]); // Set telephone number
            
            // Execute the insert statement. It returns the number of affected rows
            int affectedRows = pstmt.executeUpdate();
            
            // Check if the insert operation affected any rows.
            if (affectedRows > 0) {
                // Retrieve the generated keys
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        // If a new key was generated, add the new record to the table model for display.
                        tableModel.addRow(new Object[]{name, input[3], input[4]});
                    }
                }
            }
            
            // Clear the table model to remove all existing rows.
            tableModel.setRowCount(0);
            // Reload all entries from the database to refresh the display.
            loadEntries();
            // Clear the input fields in the GUI to reset the form for new input.
            clearInputFields();
            
        } catch (SQLException ex) { // Error handlings
            ex.printStackTrace();
            JOptionPane.showMessageDialog(TeleDirectory.this, "Error saving record to database", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Deletes a record from the database based on user selection in the table.
     */

    private void deleteRecord() {
        // Get the index of the selected row in the JTable
        int selectedRow = directoryTable.getSelectedRow();
        if (selectedRow >= 0) {
            // Convert the selected row index to model index (in case of sorting)
            int modelRow = directoryTable.convertRowIndexToModel(selectedRow);
            
            // Get the name, address, and tele number from the table model at the selected row
            String name = (String) tableModel.getValueAt(modelRow, 0);
            String address = (String) tableModel.getValueAt(modelRow, 1);
            String telephone = (String) tableModel.getValueAt(modelRow, 2);

            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                 PreparedStatement pstmt = conn.prepareStatement("DELETE FROM contacts WHERE lname = ? AND fname = ? AND mInitial = ? AND address = ? AND telephone = ?")) {
                
                // Split the name into parts: last name, first name, and middle initial
                String[] nameParts = name.split(",\\s+");
                String[] firstLast = nameParts[1].split("\\s+");
                String lastName = nameParts[0].trim();
                String firstName = firstLast[0].trim();
                String middleInitial = firstLast.length > 1 ? firstLast[1].trim() : "";
                
                // Set parameters for the prepared statement
                pstmt.setString(1, lastName);
                pstmt.setString(2, firstName);
                pstmt.setString(3, middleInitial);
                pstmt.setString(4, address);
                pstmt.setString(5, telephone);
                
                // Execute the delete operation and get the number of rows affected
                int rowsAffected = pstmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    // If deletion is successful, notify the user
                    JOptionPane.showMessageDialog(TeleDirectory.this, "Record deleted successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    // Remove the row from the table model
                    tableModel.removeRow(modelRow);
                } else {
                    JOptionPane.showMessageDialog(TeleDirectory.this, "No records deleted. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                
                tableModel.removeRow(modelRow);
                clearInputFields();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(TeleDirectory.this, "Error deleting record from database", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(TeleDirectory.this, "Please select a row to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Updates a record in the database based on user input and selection in the table.
     */
    private void updateRecord() {
        // Get the index of the selected row in the JTable
        int selectedRow = directoryTable.getSelectedRow();
        if (selectedRow >= 0) {
            // Convert the selected row index to model index (in case of sorting)
            int modelRow = directoryTable.convertRowIndexToModel(selectedRow);
            // Get the current name from the table model at the selected row
            String name = (String) tableModel.getValueAt(modelRow, 0);

            // Read user input for updated fields
            String[] input = readInput();

            // Validate input
            if (input == null || input[0].isEmpty() || input[1].isEmpty() || input[3].isEmpty() || input[4].isEmpty()) {
                JOptionPane.showMessageDialog(TeleDirectory.this, "Please fill in all required fields", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Construct the new full name with optional middle name
            String middleName = input[2].isEmpty() ? "" : " " + input[2];
            String newName = input[0] + ", " + input[1] + middleName;

            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                // Prepare the SQL statement to update a record based on last name, first name, middle initial, address, and telephone
                PreparedStatement pstmt = conn.prepareStatement("UPDATE contacts SET lname = ?, fname = ?, mInitial = ?, address = ?, telephone = ? WHERE lname = ? AND fname = ? AND address = ? AND telephone = ?")) {

                // Split the current name into parts: last name and first name
                String[] nameParts = name.split(",");
                // Set parameters for the prepared statement
                pstmt.setString(1, input[0]);                           // Updated last name
                pstmt.setString(2, input[1]);                           // Updated first name
                pstmt.setString(3, input[2]);                           // Updated middle initial
                pstmt.setString(4, input[3]);                           // Updated address
                pstmt.setString(5, input[4]);                           // Updated telephone number
                pstmt.setString(6, nameParts[0].trim());                // Current last name
                pstmt.setString(7, nameParts[1].trim().split(" ")[0]);  // Current first name
                pstmt.setString(8, (String) tableModel.getValueAt(modelRow, 1));  // Current address
                pstmt.setString(9, (String) tableModel.getValueAt(modelRow, 2));  // Current telephone number

                // Execute the update operation and get the number of affected rows
                int affectedRows = pstmt.executeUpdate();
            
                // Check if any rows were updated
                if (affectedRows > 0) {
                    // If update is successful, notify the user with an information dialog
                    JOptionPane.showMessageDialog(TeleDirectory.this, "Record updated successfully", "Update Successful", JOptionPane.INFORMATION_MESSAGE);
                
                    // Update the table model with the new values
                    tableModel.setValueAt(newName, modelRow, 0);     // Update name in the table model
                    tableModel.setValueAt(input[3], modelRow, 1);    // Update address in the table model
                    tableModel.setValueAt(input[4], modelRow, 2);    // Update telephone number in the table model
                
                    // Clear the input fields and reload the entries from the database
                    tableModel.setRowCount(0);  
                    loadEntries();              
                    clearInputFields();        
                } else {
                    // If no rows were updated, show an error message
                    JOptionPane.showMessageDialog(TeleDirectory.this, "Failed to update record", "Update Failed", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(TeleDirectory.this, "Error updating record in database", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(TeleDirectory.this, "Please select a row to update", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Reads input from the text fields.
     *
     * @return An array of Strings representing the input fields.
     */
    private String[] readInput() {
        String lastName = lNameField.getText().trim();
        String firstName = fNameField.getText().trim();
        String middleName = mNameField.getText().trim();
        String address = addressField.getText().trim();
        String telephone = numberField.getText().trim();
        return new String[]{lastName, firstName, middleName, address, telephone};
    }

    /**
     * Clears input fields.
     */
    private void clearInputFields() {
        lNameField.setText("");
        fNameField.setText("");
        mNameField.setText("");
        addressField.setText("");
        numberField.setText("");
    }

    /**
     * Loads existing entries from the database into the table.
     */
    private void loadEntries() {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT lname, fname, mInitial, address, telephone FROM contacts ORDER BY lname, fname, mInitial")) {
            
            // Iterate through the result set
            while (rs.next()) {
                // Retrieve values from the result set
                String lastName = rs.getString("lname");
                String firstName = rs.getString("fname");
                String middleInitial = rs.getString("mInitial");
                String address = rs.getString("address");
                String telephone = rs.getString("telephone");

                // Construct the name
                StringBuilder fullNameBuilder = new StringBuilder();
                
                // Construct the full name
                if (lastName != null && !lastName.trim().isEmpty()) {
                    fullNameBuilder.append(lastName.trim());
                }
                
                // Append first name with comma separator if last name exists
                if (firstName != null && !firstName.trim().isEmpty()) {
                    if (fullNameBuilder.length() > 0) {
                        fullNameBuilder.append(", ");
                    }
                    fullNameBuilder.append(firstName.trim());
                }
                // Append middle initial if not empty
                if (middleInitial != null) {
                    if (fullNameBuilder.length() > 0) {
                        fullNameBuilder.append(" ");
                    }
                    if (middleInitial.trim().isEmpty()) {
                        // Handle case where middleInitial is empty
                        fullNameBuilder.append("");
                    } else {
                        fullNameBuilder.append(middleInitial.trim());
                    }
                }
                
                // Stores the fullName in name
                String name = fullNameBuilder.toString();
                
                // Add a new row to the table model with retrieved values
                tableModel.addRow(new Object[]{name, address, telephone});
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(TeleDirectory.this, "Error loading data from database", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Main method to start the TeleDirectory application.
     *
     * @param args Command-line arguments (not used).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(TeleDirectory::new);
    }
}
