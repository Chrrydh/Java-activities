-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jun 29, 2024 at 10:31 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `telephonedirectory`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `mInitial` varchar(3) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `telephone` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `lname`, `fname`, `mInitial`, `address`, `telephone`) VALUES
(1, 'Abel', 'J.', 'G.', '110 Oakleaf', '236-4010'),
(2, 'Baker', 'Sue', '', '451 Den', '645-8978'),
(3, 'Carter', 'L.', 'H.', '17 Bernary', '567-8766'),
(4, 'Minte', 'Al', NULL, '204 Pine', '356-2453'),
(5, 'Point', 'M.', 'R.', '1 Market', '212-9841'),
(7, 'Lang', 'Al', '', '311 Moss', '716-1111'),
(8, 'Bondoc', 'Shayne', 'F.', '111 Maayusin', '987-4561'),
(9, 'De Honor', 'Charry', 'L.', '567 Hay', '987-2345'),
(10, 'Rosales', 'Angel Abegail', 'B.', '789 Fair', '789-1254'),
(11, 'Fuentes', 'Maira', '', '879 Jil', '246-7894'),
(12, 'Evans', 'R.', 'W.', '15 Birch', '777-2468'),
(13, 'Fisher', 'Leon', 'M.', '55 Walnut', '888-1357'),
(14, 'Garcia', 'Paula', 'N.', '123 Cedar', '444-6789'),
(15, 'Harris', 'T.', 'J.', '78 Cherry Ln', '222-4567'),
(16, 'Jackson', 'Amon', 'C.', '36 Sycamore Dr', '667-7890'),
(17, 'King', 'Emman', 'B.', '42 Oak St', '999-0001'),
(18, 'Minte', 'Conrad', '', '204 Pine', '356-2453'),
(19, 'Montesori', 'M.', 'R.', '18 Pine St', '789-5678'),
(20, 'O\'Connor', 'Tina', 'P.', '67 Birchwood Dr', '888-9999'),
(21, 'Patel', 'Nina', 'M.', '3 Maharlika', '789-1236'),
(22, 'Point', 'M.', 'J.', '82 Cherrywood', '333-4441'),
(23, 'Abel', 'Anna', 'S.', '55 Tuna St', '212-1456'),
(24, 'Baer', 'Sue', '', '409 Sunset Blvd', '646-5554'),
(25, 'Carter', 'L.', 'H.', '17 tIHI Rd', '917-5557'),
(29, 'Lang', 'Al', '', '456 Moss Rd', '917-5512'),
(30, 'Smith', 'John', 'D.', '123 Maple Ln', '718-7421'),
(31, 'Brown', 'Emily', 'A.', '456 Oak Dr', '646-5557'),
(32, 'Davis', 'David', '', '789 Elm Ct', '347-5554'),
(33, 'Garcia', 'Sophia', 'M.', '987 Matalino Rd', '212-5789'),
(34, 'Hernandez', 'Matthew', 'T.', '246 Birch Blvd', '917-5558'),
(35, 'Lopez', 'Olivia', '', '135 Pine Ave', '718-7541'),
(36, 'Gonzalez', 'Daniel', 'P.', '579 Rose St', '646-5551'),
(37, 'Martinez', 'Isabella', '', '864 Daisy Dr', '347-5552'),
(38, 'Perez', 'William', 'A.', '732 Tulip Ln', '212-5555'),
(39, 'Wilson', 'Mia', '', '284 Lily Rd', '917-1245'),
(40, 'Taylor', 'Alexander', 'S.', '647 Orchid St', '748-3645'),
(41, 'Thomas', 'Emma', 'E.', '910 Poplar Ave', '646-5557'),
(42, 'Moore', 'James', '', '543 Magnolia Blvd', '347-5557');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
